void tw_genSPxSPfft(float * w, int n);
static void bit_rev(float* x, int n);
static void tw_genr2fft(float* w, int n);
void tw_genr4fft(float *, int);
void R4DigitRevIndexTableGen(int n, int * count, unsigned short *IIndex, unsigned short *JIndex);
void digit_reverse(double *yx, unsigned short *JIndex, unsigned short *IIndex, int count);

/*======================================================================== */
/*            Copyright (c) 2003 Texas Instruments, Incorporated.          */
/*                           All Rights Reserved.                          */
/* ======================================================================= */

